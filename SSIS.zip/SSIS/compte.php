<!DOCTYPE html>
<html>
<head>
	<title>Page php compte</title>
	<link rel="stylesheet" type="text/css" href="CSS/menu.css">
</head>
<body>


	<a id = "Moncompte"></a>

<?php
	
	session_start();


	
	$link = new mysqli('localhost', 'root', '');
	if ($link->connect_errno) {die ("Erreur de connexion : errno: " . $link->errno . " error: " . $link->error);}
	$link->select_db('projetest') or die("Erreur selection BD: " . $link->error);


	echo "<form> 

		<input type = 'submit' name = 'Deco' value = 'Deconnexion'/>

	</form>";

	session_destroy();



?>

</body>
</html>