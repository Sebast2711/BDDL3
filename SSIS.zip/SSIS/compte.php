<!DOCTYPE html>
<html>
<head>
	<title>Page de compte php</title>
	<link rel="stylesheet" type="text/css" href="CSS/menu.css">
	<link rel="stylesheet" type="text/css" href="CSS/compte.css">
	<link rel="stylesheet" type="text/css" href="CSS/index.css">

</head>
<body>


	<a id = "Moncompte"></a>

<?php
	
	session_start();
	$pseudo = $_SESSION['Pseudo'];
	echo $_SESSION['Pseudo'];

	echo "<form method = 'post' action = 'deconnexion.php'> 
			    <div class= 'w'>
					<li><input type = 'submit' name = 'Deco' value = 'Deconnexion'/></li>
		    	</div>
		  </form>";

	echo "<a href = 'index.html#Pageprincipale'> Revenir a la page principale</a>";





?>

</body>
</html>