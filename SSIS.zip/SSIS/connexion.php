<!DOCTYPE html>
<html>
<head>
	<title>Page de connexion bis</title>
	<link rel="stylesheet" type="text/css" href="CSS/menu.css">
</head>

<body>

<?php


	$link = new mysqli('localhost', 'root', '');
	if ($link->connect_errno) {
	    die ("Erreur de connexion : errno: " . $link->errno . " error: " . $link->error);
	}
	$link->select_db('projetest') or die("Erreur selection BD: " . $link->error);


	session_start();

	if (isset ($_POST['Pseudo']) AND isset($_POST['MotDePasse'])){
		$pseudo=$_POST['Pseudo'];
		$mdp=$_POST['MotDePasse'];	
		$idc = $_POST ['id'];
	}


	$requete = "SELECT id, pseudo, motdepasse FROM client WHERE pseudo = '$pseudo' AND motdepasse = '$mdp'";
	$result = $link -> query($requete);


	while ($donnees = mysqli_fetch_object($result)){

		$_SESSION ['Pseudo'] = $donnees->pseudo;
		$_SESSION ['mdp'] = $donnees->motdepasse;
		$_SESSION ['id'] = $donnees->id;
	}


	if (!$result OR $_SESSION['Pseudo'] != $pseudo OR $_SESSION['mdp'] != $mdp  ){
		die ('Faux' );
	}

	echo "Bienvenue $pseudo";
	echo "<br><a href = 'hotel.php#pageh'> Page d'hotel </a> <br>";
	echo "<a href = 'activite.php#pagea'> Page d'activite </a> <br>";
	echo "<a href = 'voyage.php#pagev'> Page de voyage </a>";


	$link->close();
?>






</body>
</html>