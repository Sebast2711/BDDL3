<!DOCTYPE html>
<html>
<head>
	<title>Page php activite</title>
	<link rel="stylesheet" type="text/css" href="CSS/menu.css">
	<link rel="stylesheet" type="text/css" href="CSS/chambre.css">
</head>
<body>


<?php
	
	$num = $_POST['Numero'];
	
	session_start();
	$idc = $_SESSION['id'];



	$link = new mysqli('localhost', 'root', '');
	if ($link->connect_errno) {die ("Erreur de connexion : errno: " . $link->errno . " error: " . $link->error);}
	$link->select_db('projetest') or die("Erreur selection BD: " . $link->error);

	

	$requete = "INSERT INTO reservervoyage (id, n_reservation) VALUES ('$idc', '$num')";
	$result = $link -> query ($requete);





	echo "$num";


?>

</body>
</html>