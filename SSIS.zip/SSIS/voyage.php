<!DOCTYPE html>
<html>
<head>
	<title>Page php activite</title>
	<link rel="stylesheet" type="text/css" href="CSS/menu.css">
	<link rel="stylesheet" type="text/css" href="CSS/activite.css">
</head>
<body>

<a id = 'pagev'> </a>




<?php
	
	$link = new mysqli('localhost', 'root', '');
	if ($link->connect_errno) {die ("Erreur de connexion : errno: " . $link->errno . " error: " . $link->error);}
	$link->select_db('projetest') or die("Erreur selection BD: " . $link->error);



	$requete = "SELECT * FROM voyage";
	$result = $link -> query ($requete);


	echo "<form method = 'post' action = 'voyage2.php' >";
	echo "<table border = '1'>";

	while ($donnees = mysqli_fetch_object($result)){
		echo "<tr><td> $donnees->nomVilleDepart</td>";
		echo "<td>$donnees->nomVilleArrive</td>";
		echo "<td> $donnees->dateDepart</td>" ;
		echo "<td> $donnees->dateArrive</td>" ;
		echo "<td> $donnees->typeTransport</td>" ;
		echo "<td> $donnees->prix</td>" ;
		echo "<td><input type = 'submit' name = '$donnees->n_reservation' value = 'Reserver '/><td>";
		echo "</tr>";
	}

	echo "</form>";

?>

</body>
</html>